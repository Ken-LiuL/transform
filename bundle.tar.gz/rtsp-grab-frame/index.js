/**
 * Created by pengkun on 28/2/2018.
 */
const DbManager = require("./db-manager");
const HbaseManager = require("./hbase-manager");
const debug = require("debug")("index");
const config = require("./config");
const utils = require("./utils");
const KafkaManager = require("./kafka-manager");
const Extractor = require("./extract-frame")
const ZkManager = require("./zk-manager");


class FrameCapture{
    constructor(){
        //initialization of key manager
        this.db = new DbManager(config.db);
        this.extractors = {};
        this.hbaseClients = {};
        this.kafkaClients = {};
        this.coordinator = new ZkManager(config.zk);
        this.id = utils.getIPAdress();
        //containers

        //register self in zookeeper
        this.coordinator.on("ready", () => {
            this.coordinator.register((err, path) => {
                if(err) throw Error(`${path} can not be registered due to ${err}`);
            })
        });
        //listen to kafka
        //let topics = [{topic:"camera-put"}, {topic: "camera-post"}, {topic:"camera-delete"}];
        let topics = ["camera-put", "camera-post", "camera-delete"];
        this.consumer = new KafkaManager(config.kafka.connection).consumer(topics);
        this.consumer.consume((msg) => this.listenCommand(msg, this.id));
    }

    listenCommand(msg, id){
        let command = JSON.parse(msg.value)
        if(command.target == id ){
            switch(msg.topic){
                case "camera-put":
                    if(command.grab) this.run(command);
                    break;
            }
        }
    }

    run(record) {
        let identifier = record.name;
        let extractor = new Extractor({id: identifier, url: record.url, freq: record.framerate});
        let hbase = new HbaseManager(config.hbase);
        let producer = new KafkaManager(config.kafka.connection).producer();
        extractor.on(`${identifier}-data`, (data) => {
            let rowkey = `${new Date().getTime()}:${identifier}`;
            hbase.put(rowkey, data, (err) => {

                if (err) debug(err)
                else {
                    producer.produce([{topic: record.topic, messages: rowkey}])
                    debug(`one message produced`);
                }
            })
        });
        this.extractors[identifier] = extractor;
        this.hbaseClients[identifier] = hbase;
        this.kafkaClients[identifier] = producer;

    }

    update(){

    }

}

new FrameCapture()
