/**
 * Created by pengkun on 25/2/2018.
 */
const debug = require("debug")("frame-extract");
const P2J = require('pipe2jpeg');
const child_process = require("child_process");
const EventEmitter  = require("events").EventEmitter;


class FrameExtractor extends EventEmitter {
    constructor(options) {
        super()
        this.setMaxListeners(0);
        this.id = options.id;
        this.lastTime = 0;
        this.p2j = new P2J();
        this.freq = options.freq || 3;
        this.currentTime = 0;
        this.url = options.url;
        this._startExtractor();
        this._listenEvent();
        this._monitorExtractor();
    }

    _listenEvent(){
        this.stream.stdout.on("data", (data) => {
            this.currentTime += 1;
        })
        this.stream.stdout.pipe(this.p2j);
        this.p2j.on("jpeg", (jpeg) =>{
            this.emit(this.id + "-data", jpeg);
        })
        this.stream.stdout.on("error", (err) => {
            this.emit(this.id + "-error", err);
        })
        this.stream.stderr.on("data", (data) => {
            this.emit(this.id + "-output", data);
        });
    }

    _startExtractor() {
        this.stream = child_process.spawn("ffmpeg",
            ["-rtsp_transport", "tcp", "-i", this.url, '-c:v','mjpeg','-f','image2pipe','-q','1','-r',this.freq, '-'],
            {detached: false}
        );
    }

    _monitorExtractor(){
        this.timerExtractor = setInterval(() => {
            if (this.currentTime > this.lastTime) {
                this.lastTime = this.currentTime = 0;
            }
            else {
                debug("restart stream hangout ffmpeg");
                this.stream.stdout.end();
                this.stream.kill();
                this._startExtractor();
                this._listenEvent();
            }
        }, 5000);
    }

    destory(){
        this.timerRtp && clearInterval(this.timerExtractor);
    }
}
module.exports = FrameExtractor
