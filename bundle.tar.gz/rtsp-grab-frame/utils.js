/**
 * Created by pengkun on 3/3/2018.
 */
const os = require('os');
class Utils {
    getIPAdress() {
        let interfaces = os.networkInterfaces();
        for (let devName in interfaces) {
            var iface = interfaces[devName];
            for (var i = 0; i < iface.length; i++) {
                var alias = iface[i];
                if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal) {
                    return alias.address;
                }
            }
        }

    }
}

module.exports = new Utils();
