/**
 * Created by pengkun on 2/3/2018.
 */
const debug = require("debug")("test-throughout");
const config = require("../config");
const DbManager = require('../db-manager');




var db  = new DbManager({host:config.db.host,
    port:config.db.port,
    username: config.db.username,
    password: config.db.password,
    database: config.db.database
})

db.listCamera((err, data) =>{
    if(err) console.log(err)
    else data.map((ele) => console.log(ele.id))
})

