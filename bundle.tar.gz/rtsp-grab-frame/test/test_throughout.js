/**
 * Created by pengkun on 28/2/2018.
 */
const Extractor = require("../extract-frame")
const debug = require("debug")("test-throughout");
const HbaseManager = require("../hbase-manager");
const KafkaProducer = require("../kafka-manager");
const config = require("../config");
const EventEmitter  = require("events").EventEmitter;
const fs = require("fs")

console.log(config.hbase.table)



var exs =[]
for(var i =0;i<3; i++){
    exs.push(new Extractor({id:'test', url:"rtsp://admin:123456@192.168.1.71:554/h264/ch1/main/av_stream"}))
}



exs.forEach((ex) =>{
    const Hbase = new HbaseManager({table: config.hbase.table,cf:config.hbase.cf ,col: config.hbase.col, host: config.hbase.host, port:config.hbase.port})
    const Kafka = new KafkaProducer(config.kafka.connection)
    ex.on('test-data', (data) =>{
        let rk = new Date().getTime() + '';
        rk = rk.split("").reverse().join("")
        let start = new Date().getTime();
        Hbase.put(rk, data, (err) => {
            if (err) debug(err);
            else {
                Kafka.produce([{topic: config.kafka.topic, messages: rk}], ()=> {
                    console.log(new Date().getTime() - start)
                });
            }
        });
    })
    }
);






