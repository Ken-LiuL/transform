/**
 * Created by pengkun on 28/2/2018.
 */
const zookeeper = require('node-zookeeper-client');
const EventEmitter  = require("events").EventEmitter;
const async = require("async");
const utils = require("./utils");
const debug = require("debug")("zk-manager");

class ZkManager extends EventEmitter{
    constructor(option){
        super();
        this.url = option.connection;
        this.root = option.root;
        this.client = zookeeper.createClient(this.url);
        this._ready  = false;
        this.client.on("connected", () =>{
            debug("zookeeper connected succesfully");
            this.emit("ready");
            this._ready = true;
        });
        this.client.on("close", () => {
            debug("zookeeper has been closed");
            this._ready = false;
        });
        this.client.on("error", (err) => {
            debug(`error happened for zookeeper as ${err}`);
            this._ready = false;
            this.emit("err", err);
        })
        this.client.connect();
    }

    register(cb){
        let ip = utils.getIPAdress();
        async.waterfall([
            (callback) => {
                this.checkAndCreate(this.root, (err, path) => callback(err, path))
            },
            (parent, callback) => {
                this.checkAndCreate(`${parent}/slaves`, (err,path) => callback(err, path));
            },
            (parent, callback) => {
                this.checkAndCreate(`${parent}/${ip}`, (err, path) => callback(err, path));
            }
        ], (err, path) => {
            if(err) debug(`failed to create ${path} due to ${err}`);
            cb(err);
        });
    }

    checkAndCreate(path, cb, data="") {
        async.series({
            one: (callback) => this.client.exists(path, (err, stat) => {
                if(err) callback(err)
                else {
                    if(!stat) callback(null);
                    else {
                        callback("existed", path);
                    }
                }
            }),
            two: (callback) => this.client.create(path, new Buffer(data), (err) => callback(err, path))
        }, (err, p) => {
            if(err && err != "existed") {
                debug(`failed to create ${p.two} due to ${err}`);
                cb(err, p.two);
            }
            else cb(null, p.one || p.two);
        });
    }

    isReady() {
        return this._ready;
    }


}

module.exports = ZkManager
