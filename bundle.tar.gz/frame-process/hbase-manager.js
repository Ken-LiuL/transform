/**
 * Created by pengkun on 26/2/2018.
 */
const debug = require("debug")("hbase-manager");
const thrift = require('thrift');
const HBase = require('./gen-nodejs/THBaseService');
const EventEmitter  = require("events").EventEmitter;
const HBaseTypes = require('./gen-nodejs/hbase_types');

class HbaseManager extends EventEmitter{
    constructor(option){
        super();
        this.table = option.table;
        this.col = option.col;
        this.cf = option.cf;
        this.host = option.host;
        this._ready = false;
        this.port = option.port;
        switch(option.transport) {
            case "TFramed":
                this.transport = thrift.TFramedTransport;
                break;
            case "TBuffered":
                this.transport = thrift.TBufferedTransport;
                break;
            default:
                this.transport = thrift.TFramedTransport;
        }
        switch(option.protocol){
            case "TCompact":
                this.protocol = thrift.TCompactProtocol;
                break;
            case "TBinary":
                this.protocol = thrift.TBinaryProtocol;
                break;
            case "TJSON":
                this.protocol = thrift.TJSONProtocol;
                break;

            default:
                this.protocol = thrift.TCompactProtocol;


        }
        this.connection = thrift.createConnection(this.host, this.port, {
            transport: this.transport,
            protocol: this.protocol
        });
        this.connection.on("connect", () => {
            debug("hbase connected");
            this.client = thrift.createClient(HBase,this.connection);
            this._ready = true;
            this.emit("ready");
        });
        this.connection.on("error", (err) =>{
            debug(`hbase failed to be connected: ${err}`);
            this.emit('err', err);
            this._ready = false;
        });
        this.connection.on("close", () => {
            debug(`hbase connection is closed`);
            this._ready = false;
        })

    }

    puts(list, cb, col=this.col){
       if(this._ready) {
           let putList = list.map((ele) => new HBaseTypes.TPut({
                   row: ele.rowkey,
                   columnValues: [new HBaseTypes.TColumnValue({
                       family: this.cf,
                       qualifier: this.col,
                       value: ele.data
                   })]
               })
           );
           this.client.putMultiple(this.table, putList, (err) => {
               if (err) debug(`put error for multiple puts`);
               else debug(`multiple puts succesfully`);
               cb(err)
           })
       }
       else{
           let err = "multi puts request failed due to hbase connection is not ready";
           debug(err);
           cb(err);
       }
    }

    put(rowkey, data, cb, col=this.col){
      if(this._ready) {
          let put = new HBaseTypes.TPut({
              row: rowkey,
              columnValues: [new HBaseTypes.TColumnValue({
                  family: this.cf,
                  qualifier: col,
                  value: data
              })]
          });
          this.client.put(this.table, put, (err) => {
              if (err) debug(`put error for ${rowkey} and error as: ${err}`);
              else debug(`put succesfully`);
              cb(err);
          });
      }
      else{
          let err = "put request failed due to hbase connection is not ready";
          debug(err);
          cb(err);
      }
    }

    scan(start, end, cb){
        if(this._ready){
            debug(`prepare to scan between ${start} adn ${end}`)
            var tScanner = new HBaseTypes.TScan({startRow: `${start}`, stopRow: `${end}`,
                columns: [new HBaseTypes.TColumn({family: this.cf})]});
            this.client.openScanner(this.table, tScanner, (err, scannerId) => {
                if(err) {
                    debug(`failed to open scanner due to ${err}`);
                    return cb(err);
                }
                this.client.getScannerRows(scannerId, 10, (serr, data) =>{
                    if(serr) {
                        debug(`failed to get scanner rows due to ${serr}`);
                        return cb(serr);
                    }
                    cb(null,data)
                    this.client.closeScanner(scannerId, (err) =>{
                        if(err) debug(`failed to close scanner due to ${err}`)
                    });
                });
            });
        }
        else{
            let err = `scan face failed between ${start} and ${end}`
        }
    }

    get(rowkey, cb) {
        if(this._ready) {
            let get = new HBaseTypes.TGet({
                row: rowkey,
                columns: [new HBaseTypes.TColumn({family: this.cf})]
            });
            this.client.get(this.table, get, (err, data) => {
                if (err) debug(`get error for ${rowkey} and err as: ${err}`);
                cb(err, data && data);
            });
        }
        else {
            let err = "get request failed due to hbase connection is not ready";
            debug(err);
            cb(err);
        }
    }

    isReady(){
        return this._ready;
    }

    destory(){
        this.connection.end();
    }
}


module.exports = HbaseManager





