/**
 * Created by pengkun on 4/3/2018.
 */
const HbaseManager = require("./hbase-manager");
var express = require("express");
var bodyParser = require("body-parser");
const http = require('http');
const debug = require("debug")("index");
const config = require("./config");
const KafkaManager = require("./kafka-manager");
const request = require('request');
const fs = require("fs");
const async = require("async");
const Jimp = require("jimp");
const base64 = require("64");
const vectorize = require('vectorious');
const Vector = vectorize.Vector;
const WebSocket = require('ws');
const EventEmitter  = require("events").EventEmitter;
const PORT = 2313;

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const similarity = require( 'compute-cosine-similarity' );




const NAME_SPACE= {
    feature: "v",
    face: "f",
    frame: "s",
    blacklist: "b"
}

class FrameProcess extends EventEmitter{
    constructor(){
        super()
        //initialization of key manager
        this.hbasePut = new HbaseManager(config.hbase);
        this.hbasePut.on("ready", () => this.emit("ready"));
        config.hbase.table = "frames";
        config.hbase.cf = "frame";
        this.hbaseGet = new HbaseManager(config.hbase);
        //register self in zookeeper
        this.consumer = new KafkaManager(config.kafka.connection).consumer([config.kafka.topic]);
        this.consumer.consume((msg) => this.dealFrames(msg));
        this.on("verify", (captured) => {
            let candidate = []
            async.parallel(watchlist.map((suspect) => () => {
                candidate.push[{suspectId:suspect.id,
                               similarity:similarity(captured.feature, suspect.feature),
                               matchedId:captured.id}];

            }), (err) => {
                if(err) debug(`error happend when calculate similarity between captured and suspect due to ${err}`);
                else{
                   if(candidate){
                       candidate.sort((a,b) => b.similarity - a.similarity);
                       this.emit("push", candidate[0]);
                   }
                }
            });
        })

    }

    static start(){
        return new FrameProcess();
    }

    dealFrames(msg){
        this.hbaseGet.get(msg.value, (err, data) => {
            if(err) debug(`failed to get data from hbase for ${msg.value} due to ${err}`);
            else this.detectFaces(data.columnValues[0].value, msg.value);
        });
    }

    scanFeatures(start, end, cb){
        this.hbasePut.scan(`${NAME_SPACE.feature}:${start}`, `${NAME_SPACE.feature}:${end}`, cb);
    }

    detectFaces(data, frameId, option={}){
        option = Object.assign(option,{
            url: config.api.url+"/detect",
            method: "post",
            json: {
                api_key: config.api.key,
                image_base64: base64.encode(data).toString(),
                field: "feature"
            }
        });
        request(option, (err, response, body) => {
            if(err) debug(`error happened when try to detect fase due to ${err}`);
            else{
                if(response.statusCode != 200) debug(`error for request as ${body}`);
                else{
                    if(body.error_message == "601"){
                        let frameKey = `${NAME_SPACE.frame}:${frameId}`;
                        frameKey =  option.id ? `${frameKey}:${option.id}:0`:`${frameKey}:0`;
                        this.hbasePut.put(frameKey, data, (err) => {
                            if(err) debug(`fail to put original frame due to ${err}`);
                        });
                        body.result.map((face, index) => {
                            Jimp.read(data).then((image) => {
                                let fa = image.crop(face.left, face.top, face.width, face.height);
                                let cropKey = `${NAME_SPACE.face}:${frameId}`;
                                fa.getBuffer("image/jpeg", (err,data) =>{
                                    cropKey = option.id ? `${cropKey}:${option.id}:${index}`:`${cropKey}:${index}`;
                                    this.hbasePut.put(cropKey, data, (err) => {
                                        if(err) debug(`fail to put small face due to ${err}`);
                                    });
                                });
                                }).catch((err) => {
                                    if(err) debug(`failed to crop face due to ${err}`);
                                });
                            let featureKey = `${NAME_SPACE.feature}:${frameId}`;
                            featureKey = option.id ? `${featureKey}:${option.id}:${index}`:`${featureKey}:${index}`;
                            this.hbasePut.put(`${NAME_SPACE.feature}:${frameId}:${index}`,
                                              Buffer.from(JSON.stringify(face.feature)),
                                              (err) =>{
                                if(err) debug(`fail to put feature due to ${err}`);
                                this.emit("verify", {id:`${NAME_SPACE.feature}:${frameId}:${index}`,feature:face.feature});
                            })
                        });
                    }
                    else {
                        debug(`no face detected with code ${body.error_message}`)
                    }
                }
            }
        });
    }
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.post("/watchlist", (req, res) => {
     req.body.map((item) => {
         request({
            url: item.url,
            method: "GET",
             encoding: null
         }, (err, response, body) => {
             if(err ) return res.json({status:500, message:`failed to get people's image due to ${err}`})
             else{
                 if(response.statusCode != 200){
                     return res.json({status:response.statusCode, message:`failed to get people's image due to ${body}`})
                 }
                 else{
                    grabber.detectFaces(body, NAME_SPACE.blacklist, {id: item.id})
                 }
             }
         });
     })
});

app.get("/image/:url", (req, res) => {
    console.log(req.params.url);
    grabber.hbasePut.get(req.params.url, (err, data) => {
        if(err) {
            debug(`error happened when retrieve image ${req.params.url}`);
            res.sendStatus("404");
            res.end();
        }
        else{
            res.setHeader("Content-Type", "image/jpg");
            res.writeHead(200, "Ok");
            res.write(data.columnValues[0].value.toString(),"binary"); //格式必须为 binary，否则会出错
            res.end();
        }
    });
})

var grabber;
var watchlist = []


wss.on("connection", (ws, req) => {
   grabber.on("push", (data) => {
       ws.send(data);
   })
});

server.listen(PORT, function () {
    var host = server.address().address;
    var port = server.address().port;
    grabber = FrameProcess.start()
    /*grabber.on("ready", () => grabber.scanFeatures("b", "c", (err, data) => {
        if(err) debug(`failed to get watchlist data due to ${err}`);
        else {
            watchlist = data.map((record) => {
                return {
                        id: record.row.toString().split(":").slice(-1)[0],
                        feature:JSON.parse(record.columnValues[0].value.toString())
                      };
            });
        }
    }));*/
    console.log('Example app listening at http://%s:%s', host, port);
});
