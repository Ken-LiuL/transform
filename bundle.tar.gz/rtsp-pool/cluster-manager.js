/**
 * Created by pengkun on 3/3/2018.
 */
const debug =  require("debug")("utils");
const ZkManager = require("./zk-manager");
const async = require("async");
const _ = require("lodash");
const EventEmitter  = require("events").EventEmitter;
const  config = require("./config")

class ClusterManager extends EventEmitter{
    constructor(){
        super();
        this.root = config.zk.path;
        this.zk = new ZkManager(config.zk);
        this.zk.once("ready", () => {
            this.zk.checkAndCreate(this.root, (err) => {
                if(err) throw new Error(`fail to create root due to ${err}`)
                //this.zk.checkAndCreate(`${this.root}/heartbeat`, (err) => {
                //    if(err) throw new Error(`fail to create heartbeat due to ${err}`);
                //});
                this.zk.checkAndCreate(`${this.root}/slaves`, (err) => {
                    if(err) throw new Error(`fail to create slaves due to ${err}`);
                });
            });
        });
        this.zk.on("err", (err) => {
            throw new Error(`zookeeper connection error due to ${err}`);
        });
    }


    slaveChanged(event){
        console.log(event);
    }


    heartbeat(){
        return ;
    }

    removeDeadSlave(){
        return ;
    }

    getSlaves(cb){
        this.zk.getChildren(`${this.root}/slaves`, (err,children) => {
            if(err) debug(`${err} happened when try to get slaves`);
            cb(err, children);
        }, this.slaveChanged);
    }


    dispatch(results, cb){
        if(results.length == 0) return cb("not camera available");
        let assignment = {};
        let cluster = [];
        this.getSlaves((err, children) => {
            if(err) return;
            let root = `${this.root}/slaves`;
            async.parallel(children.map((id) => (callback) => {
               let machine = {id:id};
               this.zk.getData(`${root}/${id}`,(err, data) => {
                    if(err) {
                        console.error(`failed to get data of machine ${id}`);
                        callback(err);
                    }
                    else machine.capacity = parseInt(data);
                    cluster.push(machine);
                    callback(null, null);
               });
            }),
            (err) =>{
               debug(`cluster info collected as ${JSON.stringify(cluster)}` );
               if(cluster.length == 0) return cb("no slave available");
               let i = 0;
               let len = results.length;
               while(results.length > 0){
                   if(i >= len ) break;
                   let slot = i % cluster.length;
                   let assignKey = cluster[slot].id;
                   if(!assignment[assignKey]) assignment[assignKey] = [];
                   if(cluster[slot].capacity > assignment[assignKey].length) assignment[assignKey].push(results.pop());
                   i = i+1;
               }
               //store the unassigned streams, which may be empty array
               this.unassign = results;
               //messages need to be sent to kafka
               let messages = [];
               async.parallel(_.flatMap(Object.keys(assignment), (key) => {
                    return assignment[key].map((camera) => (callback) => {
                        this.zk.checkAndCreate(`${root}/${key}/${camera.id}`, (err) => {
                            messages.push({
                                target: key,
                                url: camera.inner_ip,
                                topic: camera.topic,
                                framerate: camera.framerate,
                                grab: camera.grab,
                                name: camera.name
                            });
                            callback(err);
                        });
                    })
                 }), (err) => {
                   if(err) debug(`error happened when assign tasks to slaves due to ${err}`);
                   else debug(`ready to send put messages as ${JSON.stringify(messages)}`)
                   cb(err, messages);
               });
            });
        });
    }
}

module.exports = new ClusterManager();
