/**
 * Created by pengkun on 25/2/2018.
 */
const kafka = require('kafka-node'),
    debug = require("debug")("kafka-producer"),
    EventEmitter  = require("events").EventEmitter;
    Client = kafka.Client,
    Producer = kafka.HighLevelProducer,
    Consumer = kafka.ConsumerGroup

class KafkaManager extends EventEmitter{
    constructor(host) {
        super();
        this.client = new Client(host);
    }

    producer(){
        this.producer = new Producer(this.client, {partitionerType: 2});
        this.producer.on("ready", () => {
            debug("kafka producer initialized succesfully");
            this._ready = true;
        })
        this.producer.on("error", (err) => {
            debug(`kafka producer error happend as ${err}`);
            this._ready = false;
        });
        this.producer.on("close", () =>{
            debug(`kafka producer is closed `)
            this._ready = false;
        })
        return this;
    }

    consumer(topics){
        this.consumer = new Consumer({host:this.host},topics);
        this.consumer.on("error", (err) => {
            debug(`kafka consumer error happend as ${err}`);
        })
        return this;
    }

    consume(cb){
        this.consumer.on("message", (msg) => {
            cb(msg);
        });
    }

    produce(msg, cb) {
        if (this._ready) {
            msg.attributes = 2
            this.producer.send(msg, (err, data) => {
                if(err) debug(`message ${msg} sent error as ${err}`);
                else  debug('message sent succesfully');
                if(cb) cb(err, data);
            });
        }
        else {
            debug("producer is not ready");
            cb("producer is not ready");
        }
    }

    isReady() {
        return this._ready;
    }

    destroy(){
        this.client.close();
    }
}
module.exports = KafkaManager
