/**
 * Created by pengkun on 2/3/2018.
 */
var express = require("express");
var bodyParser = require("body-parser");
var DbManager =  require("./db-manager");
var debug =  require("debug")("index");
var KafkaManager = require("./kafka-producer");
const config = require("./config");
const cluster = require("./cluster-manager");
var app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var producer = new KafkaManager(config.kafka.connection).producer();
var db = new DbManager(config.db);


function initialize(){
    db.listCamera((err, results) => {
        if(err)  throw new Error(`server failed to start due to ${err}`)
        else  cluster.dispatch(results, (err, msg) => {
            if(err) debug(`tasks initialization dispatch failed due to ${err}`);
            if(results) {
                 producer.produce([{topic: "camera-put", messages: msg.map((ms) => JSON.stringify(ms))}], (err) => {
                        if (err) new Error(`kafka sent msg failed due to ${err}`);
                 });
            }
        });
    });
}

app.put("/camera", (req, res) => {
    db.addCamera(req.body, (err) => {
       if(err) res.json({status:500, msg: "failed to add camera"});
       else  {
           res.json({status: 200, msg:"succeed to add camera"});
       }
    });
});

app.post("/camera/:id", (req, res) =>{
    db.updateCamera(req.params.id, req.body, (err) => {
        if(err) res.json({status: 500, msg: `failed to update camera ${id} to ${req.body}`});
        else res.json({status: 200, msg: "succeed to update camera"});
    })
});

app.delete("/camera/:id", (req, res) => {
    db.deleteCamera(req.params.id, (err) => {
        if(err) res.json({status: 500, msg: `failed to delete camera for ${id}`});
        else res.json({status: 200, msg: "succeed to delete camera"});
    })
});

app.put("/cameras", (req, res) => {
    db.addCameras(req.body, (err) => {
        if(err) res.json({status: 500, msg: `failed to add cameras for ${req.body}`});
        else res.json({status: 200, msg: "succeed to add cameras"});
    })
});

app.delete("/cameras", (req, res) => {
    db.deleteCameras(req.body, (err) => {
        if(err) res.json({status: 500, msg: `failed to delete cameras for ${req.body}`})
        else res.json({status: 200, msg: "succeed to delete cameras"});
    });
});

app.get("/cameras", (req, res) => {
    db.listCamera((err, results) => {
        if(err) res.json({status:500, msg: "failed to list camera"});
        else  res.json(results);
    });
})

//temp

var server = app.listen(PORT, function () {
    var host = server.address().address;
    var port = server.address().port;
    initialize();
    console.log('Example app listening at http://%s:%s', host, port);
});
