/**
 * Created by pengkun on 28/2/2018.
 */
const debug = require("debug")("db-manager");
var mysql = require('mysql');

class DbManager{
    constructor(option){
        this.host = option.host;
        this.port = option.port;
        this.username = option.username;
        this.password = option.password;
        this.database = option.database;
        this.table = option.table;
        this.pool = mysql.createPool({
            host: this.host,
            user: this.username,
            port: this.port,
            password: this.password,
            database: this.database
        })
    }

    query(queryStr, params=null, cb){
        this.pool.getConnection((err, connection) =>{
            if(err) debug(`failed to connect to ${this.host}:${this.port} with ${this.username} and ${this.password} for ${this.database}`)
            else connection.query(queryStr,params, (err, results, fields) => {
                connection.release();
                if(err) debug(`failed to ${queryStr} to ${this.host}:${this.port} with ${this.username} and ${this.password} for ${this.database}`)
                cb(err,results);
            });
        });
    }


    listCamera(cb){
        this.query("select * from metadata.camera", cb);
    }

    addCamera(obj, cb){
        this.query("insert into metadata.camera set ?", obj, cb);
    }

    addCameras(obj, cb){
        this.query("insert into metadata.camera set ?", obj, cb);
    }

    deleteCamera(id, cb){
        this.query(`delete from metadata.camera where id=${id}`, cb);
    }

    deleteCameras(ids, cb){
        this.query(`delete from metadata.camera where id in ${ids}`, cb);
    }

    updateCamera(id, obj, cb){
        this.query(`update metadata.camera set ? where id=?`, [obj, id], cb);
    }
}
module.exports = DbManager

