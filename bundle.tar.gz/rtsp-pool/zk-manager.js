/**
 * Created by pengkun on 28/2/2018.
 */
const zookeeper = require('node-zookeeper-client');
const EventEmitter  = require("events").EventEmitter;
const async = require("async");
const debug = require("debug")("zk-manager");

class ZkManager extends EventEmitter{
    constructor(option){
        super();
        this.url = option.connection;
        this.client = zookeeper.createClient(this.url);
        this._ready  = false;
        this.client.on("connected", () =>{
            debug("zookeeper connected succesfully");
            this.emit("ready");
            this._ready = true;
        });
        this.client.on("close", () => {
            debug("zookeeper has been closed");
            this._ready = false;
        });
        this.client.on("error", (err) => {
            debug(`error happened for zookeeper as ${err}`);
            this.emit("err", err);
            this._ready = false;
        })
        this.client.connect();
    }


    getChildren(path, cb, watcher){
        this.client.getChildren(path,(event) =>{
            debug(`Got watch event: ${event}`)
            if(watcher) {
                watcher(event);
                this.getChildren(a=>0, watcher);
            }
        }, (err, children, stat) => {
                if(err) debug(`failed to get children of ${path}`);
                else  cb(err, children);
        });
    }

    exists(path, cb){
        this.client.exists(path, (err, stat) => {
            if(err) debug(`failed to check existence of ${path} due to ${err}`);
            cb(err, stat);
        });
    }

    checkAndCreate(path, cb, data="") {
        async.series({
            one: (callback) => this.client.exists(path, (err, stat) => {
                if(err) callback(err)
                else {
                    if(!stat) callback(null);
                    else {
                        callback("existed", path);
                    }
                }
            }),
            two: (callback) => this.client.create(path, new Buffer(data), (err) => callback(err, path))
        }, (err, p) => {
            if(err && err != "existed") {
                debug(`failed to create ${p.two} due to ${err}`);
                cb(err, p.two);
            }
            else cb(null, p.one || p.two);
        });
    }

    create(path,cb, data=""){
        this.client.create(path, new Buffer(data), (err) => {
            if(err) debug(`${path} node failed to be created due to ${err}`);
            cb(err);
        });
    }

    getData(path, cb, watcher){
        this.client.getData(path, (event)=>{
            debug(`Got event ${event}`);
            if(watcher){
                watcher(event)
                this.getData(path,a=>0, watcher);
            }
        } ,(err, data, stat) => {
            if(err) debug(`${path} node failed to get data due to ${err}`);
            cb(err,  data && data.toString("utf8") || "12");
        });
    }

    isReady(){
        return this._ready;
    }


}
module.exports = ZkManager
